CREATE INDEX idx_road_id ON nz_roads_subsections_addressing USING btree (road_id);
ALTER TABLE nz_street_address ADD COLUMN is_odd boolean;
ALTER TABLE nz_street_address ADD COLUMN rna_id integer;
UPDATE nz_street_address SET is_odd = MOD(address_number,2) = 1;
UPDATE nz_street_address SET rna_id = nz_roads_subsections_addressing.road_id from nz_roads_subsections_addressing where nz_roads_subsections_addressing.road_section_id = nz_street_address.road_section_id

--now add indexes for speed
CREATE INDEX IF NOT EXISTS idx_rna_sae_id ON nz_street_address USING btree (rna_id);
CREATE INDEX IF NOT EXISTS idx_rna_sae_id_is_odd ON nz_street_address USING btree (rna_id,is_odd);
